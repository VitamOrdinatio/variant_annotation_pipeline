# stage_07_stop_gained_examples

## Source

- Source file: `/mnt/storage/vap_runs/HG002/run_2026_04_17_082417/raw_mark_outputs/processed/HG002_run_2026_04_17_082417.annotated_variants.tsv`
- Run ID: `run_2026_04_17_082417`
- Sample/Dataset: `HG002`

## Method

Artifacts are generated using a config-driven extraction system ("Artificer") and curated for clarity.

## Output

| sample_id | run_id | source_pipeline | variant_id | chromosome | position | reference_allele | alternate_allele | quality_flag | gene_id | gene_symbol | transcript_id | consequence | impact_class | impact | variant_class | variant_type | clinical_significance | clinvar_significance | population_frequency | gnomad_af | exac_af | thousand_genomes_af | mito_flag | epilepsy_flag |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| HG002 | run_2026_04_17_082417 | variant_annotation_pipeline | 1:48242556:G:T | 1 | 48242556 | G | T | PASS | ENSG00000117834 | SLC5A9 | ENST00000438567.7 | stop_gained | HIGH | HIGH | SNV | coding | benign | benign | 0.1138 | 0.1138 | NA | 0.1142 | False | False |
| HG002 | run_2026_04_17_082417 | variant_annotation_pipeline | 1:120466107:C:G | 1 | 120466107 | C | G | PASS | ENSG00000270231 | NBPF8 | ENST00000698216.1 | stop_gained | HIGH | HIGH | SNV | coding | NA | NA | 0.4942 | 0.4942 | NA | NA | False | False |
| HG002 | run_2026_04_17_082417 | variant_annotation_pipeline | 1:152350656:G:T | 1 | 152350656 | G | T | PASS | ENSG00000143520 | FLG2 | ENST00000388718.5 | stop_gained | HIGH | HIGH | SNV | coding | benign | benign | 0.3169 | 0.3169 | NA | 0.2905 | False | False |
| HG002 | run_2026_04_17_082417 | variant_annotation_pipeline | 1:155631436:G:A | 1 | 155631436 | G | A | PASS | ENSG00000287839 | NA | ENST00000713940.1 | stop_gained | HIGH | HIGH | SNV | coding | NA | NA | 0.6731 | 0.6731 | NA | NA | False | False |
| HG002 | run_2026_04_17_082417 | variant_annotation_pipeline | 1:158579702:C:T | 1 | 158579702 | C | T | PASS | ENSG00000279111 | OR10X1 | ENST00000623167.1 | stop_gained | HIGH | HIGH | SNV | coding | NA | NA | 0.5024 | 0.5024 | NA | 0.5741 | False | False |
| HG002 | run_2026_04_17_082417 | variant_annotation_pipeline | 1:161506414:C:T | 1 | 161506414 | C | T | PASS | ENSG00000143226 | FCGR2A | ENST00000271450.12 | stop_gained | HIGH | HIGH | SNV | coding | benign | benign | 0.0561 | 0.0561 | NA | 0.0121 | False | False |
| HG002 | run_2026_04_17_082417 | variant_annotation_pipeline | 1:171208951:C:T | 1 | 171208951 | C | T | PASS | ENSG00000094963 | FMO2 | ENST00000209929.10 | stop_gained | HIGH | HIGH | SNV | coding | benign | benign | 0.9537 | 0.9537 | NA | 0.8427 | False | False |
| HG002 | run_2026_04_17_082417 | variant_annotation_pipeline | 1:247949724:T:A | 1 | 247949724 | T | A | PASS | ENSG00000279263 | OR2L8 | ENST00000623922.1 | stop_gained | HIGH | HIGH | SNV | coding | NA | NA | 0.7458 | 0.7458 | NA | 0.2867 | False | False |
| HG002 | run_2026_04_17_082417 | variant_annotation_pipeline | 10:122454839:C:T | 10 | 122454839 | C | T | PASS | ENSG00000254636 | ARMS2 | ENST00000528446.1 | stop_gained | HIGH | HIGH | SNV | coding | benign&likely_benign | benign&likely_benign | 0.1144 | 0.1144 | NA | 0.056 | False | False |
| HG002 | run_2026_04_17_082417 | variant_annotation_pipeline | 11:5422906:C:T | 11 | 5422906 | C | T | PASS | ENSG00000167360 | OR51Q1 | ENST00000300778.4 | stop_gained | HIGH | HIGH | SNV | coding | NA | NA | 0.4539 | 0.4539 | NA | 0.2799 | False | False |

## Interpretation

Stop-gained variants are classified as HIGH impact, but:

- many occur at moderate to high population frequency  
- several are annotated as benign in ClinVar  

This demonstrates that:

- functional impact ≠ clinical pathogenicity  
- population frequency is essential for interpretation  

These variants will be filtered in downstream prioritization stages.

## Notes

- No additional notes.

## Limitations

- Excerpt or summary only.
- Not the full dataset unless explicitly stated.
- No new inference performed.
